<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<div class="collapse navbar-collapse" id="collapse">
    <ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>inicio</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>usuarios</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Formularioss</a></li>

			</ul>
</div>

<div class="modal fade" id="modalCRUD" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
            </div>
        <form id="formPersonas">    
            <div class="modal-body">
                <div class="form-group">
                <label for="name" class="col-form-label">Nombre:</label>
                <input type="text" class="form-control" id="nombre">
                </div>
                <div class="form-group">
                <label for="username" class="col-form-label">Usuario:</label>
                <input type="number" class="form-control" id="cedula">
                </div>                
                <div class="form-group">
                <label for="emal" class="col-form-label">Email:</label>
                <input type="number" class="form-control" id="edad">
                </div>
                <div class="form-group">
                <label for="password" class="col-form-label">Contraseña:</label>
                <input type="text" class="form-control" id="produto">
                </div>                        
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-light" data-dismiss="modal">Cancelar</button>
                <button type="submit" id="btnGuardar" class="btn btn-dark">Guardar</button>
            </div>
        </form>    
        </div>
    </div>
</div>  

    <div class="Reports">
    <li><a href="reportes/index.php"><span class="glyphicon glyphicon-modal-window"></span>REportes</a></li>
    <li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>REportes Personalizados</a></li>
    </div>



</body>
</html>